import time

from behave import when, then, given
from pages.login_page import LoginPage
from utils.Logger import Logger

@given("Launch application")
def step_launch_app(context):
    url = context.config_data.get("base_url")
    context.driver.get(url)
    Logger.info(f"Navigated to: {url}")
    context.login_page = LoginPage(context.driver)
    time.sleep(5)

@when("the user logs in with valid credentials")
def step_login(context):
    user = context.login_user  # Always loaded from Login sheet
    username = user.get("username")
    password = user.get("password")

    Logger.info(f"Attempting login with username: {username}")
    context.login_page.login(username, password)
    Logger.info("Login submitted.")

@then("the dashboard should be visible")
def step_verify_dashboard(context):
    current_url = context.driver.current_url.lower()
    page_title = context.driver.title.lower()

    Logger.info(f"Verifying dashboard. URL: {current_url}, Title: {page_title}")

    assert "home" in current_url or "lightning" in current_url, \
        "Dashboard is not visible after login."

    Logger.info("✅ Dashboard verification passed.")
