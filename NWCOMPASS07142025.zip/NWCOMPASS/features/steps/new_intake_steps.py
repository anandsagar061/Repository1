import time
from behave import given, when, then
from utils.ExcelUtility import ExcelUtility
from utils.Logger import Logger
from pages.new_intake_page import NewIntakePage

@given('Verify App launcher is "{expected_app}"')
def step_verify_app_launcher(context, expected_app):
    context.intake_page = NewIntakePage(context.driver)
    context.intake_page.switch_to_nw_compass(expected_app)
    Logger.info(f"App is set to: {expected_app}")

@then("Verify '{tab_name}' appears as one of the tabs on home page")
def step_verify_tab_visible(context, tab_name):
    context.intake_page = NewIntakePage(context.driver)
    assert context.intake_page.verify_client_lookup_tab_visible(tab_name)
    Logger.info(f"'{tab_name}' tab is visible.")

@then("Click on '{tab_name}'")
def step_click_tab(context, tab_name):
    context.intake_page = NewIntakePage(context.driver)
    context.intake_page.click_client_lookup(tab_name)
    Logger.info(f"Clicked on tab: {tab_name}")

@then("Verify '{button_name}' button appears as one of the buttons on top right corner")
def step_verify_button(context, button_name):
    assert context.intake_page.verify_new_intake_button_visible(button_name)
    Logger.info(f"Verified button visible: {button_name}")

@then("Click on '{button_name}' button")
def step_click_button(context, button_name):
    context.intake_page.click_new_intake_button(button_name)
    Logger.info(f"Clicked on button: {button_name}")
@when("the user fills the intake form using current Excel row")
def step_fill_from_row(context):
    data = context.test_data
    if not data:
        raise Exception("No test data found in context. Ensure @datadriven tag is set.")
    print(data.get("Case Type"))
    print(data.get("HUD Referral Source"))
    print(data.get("First Name"))
    context.intake_page.select_dropdown_by_label("Case Type",data.get("Case Type"))
    context.intake_page.select_dropdown_by_label("HUD Referral Source",data.get("HUD Referral Source"))
    context.intake_page.firstname_input(data.get("First Name"))
    context.intake_page.lastname_input(data.get("Last Name"))
    context.intake_page.email_address(data.get("Email Address"))
    context.intake_page.dob(data.get("Birthdate"))
    context.intake_page.mailing_street(data.get("Street"))
    context.intake_page.mailing_city(data.get("City"))
    context.intake_page.select_dropdown_by_label("State / Province",data.get("State"))
    context.intake_page.mailing_postcode(data.get("Postal Code"))
    time.sleep(5)
    context.intake_page.select_dropdown_by_label("County", data.get("County"))
    context.intake_page.select_dropdown_by_label("Race",data.get("Race"))
    context.intake_page.select_dropdown_by_label("Ethnicity",data.get("Ethnicity"))
    context.intake_page.select_dropdown_by_label("Gender",data.get("Gender"))
    context.intake_page.select_dropdown_by_label("Farm Worker",data.get("Farm Worker"))
    context.intake_page.select_dropdown_by_label("Education",data.get("Education"))
    context.intake_page.select_dropdown_by_label("Marital Status",data.get("Marital Status"))
    context.intake_page.select_english_proficiency("English Proficiency",data.get("English Proficiency"))
    context.intake_page.select_colonias_option("Colonias Resident",data.get("Colonias Resident"))
    context.intake_page.active_military_option("Active Military",data.get("Active Military"))
    context.intake_page.veteran_option("Veteran", data.get("Veteran"))
    context.intake_page.disabled_status_option("Disabled Status", data.get("Disabled Status"))
    context.intake_page.first_time_homebuyer_option("1st Time Home Buyer", data.get("1st Time Home Buyer"))
    context.intake_page.rural_area_status_option("Rural Area Status", data.get("Rural Area Status"))
    context.intake_page.household_type_option("Household Type", data.get("Household Type"))
    context.intake_page.household_size_input(data.get("Household Size"))
    context.intake_page.total_monthly_income_input(data.get("Total Monthly Income"))
    context.intake_page.no_of_dependents_input(data.get("Number of Dependents"))
    context.intake_page.occupation_input(data.get("Occupation"))
    context.intake_page.occupation_start_date_option("Occupation Start Date",data.get("Occupation Start Date"))
    context.intake_page.monthly_creditors(data.get("Monthly Creditor's Debt"))
    context.intake_page.client_hud_assistance_option("Client HUD Assistance", data.get("Client HUD Assistance"))
    context.intake_page.current_residence_option("Current Residence", data.get("Current Residence"))
    context.intake_page.occupation_start_date_option("Occupation Start Date", data.get("Occupation Start Date"))
    context.intake_page.next_button()
    context.intake_page.next_button()

    Logger.info("Filled intake form using Excel row")

@then("the intake should be submitted successfully")
def step_submit_intake(context):
    context.intake_page.submit_form()
    Logger.info("Intake form submitted successfully")
