import os
import json
from datetime import datetime
from utils.BrowserManager import BrowserManager
from utils.ExcelUtility import ExcelUtility
from utils.Logger import Logger

def before_all(context):
    print("✅ before_all() is executing!")

    # Load config
    with open("config.json") as f:
        context.config_data = json.load(f)

    # Load login data as list (even if only one row)
    login_data = ExcelUtility().read_excel("data/test_data.xlsx", "Login")
    context.login_data = login_data if isinstance(login_data, list) else [login_data]
    context.login_index = -1  # Will rotate users

    # Load intake data (list of rows)
    intake_data = ExcelUtility().read_excel("data/test_data.xlsx", "Intake")
    context.all_rows = intake_data if isinstance(intake_data, list) else [intake_data]
    context.row_index = -1


def before_scenario(context, scenario):
    Logger.info(f"Starting scenario: {scenario.name}")

    # Start browser
    browser = context.config_data.get("browser", "chrome")
    headless = context.config_data.get("headless", False)
    browser_manager = BrowserManager(browser, headless)
    context.driver = browser_manager.get_driver()
    context.driver.maximize_window()

    # Rotate through login users
    context.login_index += 1
    if context.login_index >= len(context.login_data):
        context.login_index = 0
    context.login_user = context.login_data[context.login_index]

    # For data-driven or intake scenarios, load intake data
    if "intake" in scenario.tags or "datadriven" in scenario.tags:
        context.row_index += 1
        if context.row_index >= len(context.all_rows):
            scenario.skip("No more rows in Intake sheet.")
        else:
            context.test_data = context.all_rows[context.row_index]
    else:
        # For login-only scenarios or background steps
        context.test_data = context.login_user

def after_scenario(context, scenario):
    if scenario.status == "failed":
        Logger.error(f"Scenario failed: {scenario.name}")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        screenshot_dir = "screenshots"
        os.makedirs(screenshot_dir, exist_ok=True)
        screenshot_path = os.path.join(screenshot_dir, f"{scenario.name}_{timestamp}.png")
        context.driver.save_screenshot(screenshot_path)
    else:
        Logger.info(f"Scenario passed: {scenario.name}")

    context.driver.quit()

def after_all(context):
    Logger.info("Test execution completed.")