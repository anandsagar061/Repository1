from selenium.webdriver.common.by import By

class IntakeLocators:
    APP_NAME_TEXT = (By.XPATH, "//h1[contains(@class,'appName')]/span")
    APP_LAUNCHER_BUTTON = (By.XPATH, "//button[@title='App Launcher']")
    VIEW_ALL_BUTTON = (By.XPATH, "//button[text()='View All']")
    NW_COMPASS_APP_DIV = lambda app: (By.XPATH, f"//div[@data-name='{app}']")
    CLIENT_LOOKUP_TAB = lambda value: (By.XPATH, f"//a[@title='{value}']")
    NEW_INTAKE_BUTTON = lambda text: (By.XPATH, f"//button[text()='{text}']")

    @staticmethod
    def DROPDOWN_BUTTON_BY_LABEL(label):
        return By.XPATH, f"//button[@aria-label=\"{label}\"]"

    FIRST_NAME_INPUT = By.XPATH, "(//input[@name='FirstName'])[2]"
    LAST_NAME_INPUT = By.XPATH, "(//input[@name='LastName'])[2]"
    EMAIL_INPUT = By.XPATH, "//*[text()='SSN']//following::input[@name='Email']"
    BIRTHDATE_INPUT = By.XPATH, "//input[@name='Birthdate']"
    MailingStreet = By.XPATH, '//*[@name="MailingStreet"]'
    MailingCity = By.XPATH, '//*[@name="MailingCity"]'
    MailingPostCode = By.XPATH, '//*[@name="MailingPostalCode"]'
    @staticmethod
    def english_option(value):
        return By.XPATH, f"//*[text()='English Proficiency']//following::*[text()='{value}']"

    @staticmethod
    def colonias_option(value):
        return By.XPATH, f"//*[text()='Colonias Resident']//following::*[text()='{value}']"

    @staticmethod
    def active_military_option(value):
        return By.XPATH, f"//*[text()='Active Military']//following::*[text()='{value}']"

    @staticmethod
    def veteran_option(value):
        return By.XPATH, f"//*[text()='Veteran']//following::*[text()='{value}']"

    @staticmethod
    def disabled_status_option(value):
        return By.XPATH, f"//*[text()='Disabled Status']//following::*[text()='{value}']"

    @staticmethod
    def first_time_homebuyer_option(value):
        return By.XPATH, f"//*[text()='1st Time Home Buyer']//following::*[text()='{value}']"

    @staticmethod
    def rural_area_status_option(value):
        return By.XPATH, f"//*[text()='Rural Area Status']//following::span[@title='{value}']"

    Household_Size_Input = (By.XPATH, "//input[@name='HouseholdSize__c']")
    TotalMonthlyIncome_Input = (By.XPATH, "//input[@name='TotalMonthlyIncome__c']")
    NumberOfDependents_Input = (By.XPATH, "//input[@name='NumberOfDependents__c']")
    Occupation_Input = (By.XPATH, "//input[@name='Occupation__c']")
    OccupationStartDate_Input = (By.XPATH, "//input[@name='OccupationStartDate__c']")
    MonthlyCreditorsDebt_Input = (By.XPATH, "//input[@name='MonthlyCreditorsDebt__c']")

    @staticmethod
    def client_hud_assistance_option(value):
        return By.XPATH, f"//*[text()='Client HUD Assistance']//following::*[text()='{value}']"

    @staticmethod
    def current_residence_option(value):
        return By.XPATH, f"//*[text()='Current Residence']//following::*[text()='{value}']"

    @staticmethod
    def household_type_option(value):
        return By.XPATH, f"//*[text()='Household Type']//following::*[@title='{value}']"

    occupation_start_date_option = (By.XPATH, '//*[text()="Occupation Start Date"]//following::input[1]')

    Next_Button = (By.XPATH, '//button[text()="Next"]')

    Submit_Button = (By.XPATH, '//button[text()="Submit"]')