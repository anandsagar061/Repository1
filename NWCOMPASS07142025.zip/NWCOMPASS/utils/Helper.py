import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from utils.Logger import Logger


class Helper:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 15)

    def enter_text(self, by, locator, value):
        element = self.wait.until(EC.visibility_of_element_located((by, locator)))
        element.clear()
        element.send_keys(value)

    def click(self, by, locator):
        element = self.wait.until(EC.element_to_be_clickable((by, locator)))
        self.driver.execute_script("arguments[0].scrollIntoView(true);",element)
        time.sleep(2)
        element.click()

    def is_element_visible(self, by, locator):
        return self.wait.until(EC.visibility_of_element_located((by, locator)))

    def get_title(self):
        return self.driver.title

    def get_text(self, by, locator):
        element = self.wait.until(EC.visibility_of_element_located((by, locator)))
        return element.text

    def is_present(self, by, locator):
        try:
            self.wait.until(EC.presence_of_element_located((by, locator)))
            return True
        except:
            return False

    def wait_until_disappears(self, by, locator):
        self.wait.until(EC.invisibility_of_element_located((by, locator)))

    def safe_click(self, by, locator):
        try:
            element = self.wait.until(EC.element_to_be_clickable((by, locator)))
            element.click()
        except Exception:
            element = self.wait.until(EC.presence_of_element_located((by, locator)))
            self.driver.execute_script("arguments[0].scrollIntoView({behavior:'smooth', block:'center'});", element)
            self.driver.execute_script("arguments[0].click();", element)
