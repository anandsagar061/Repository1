import openpyxl

class ExcelUtility:
    def read_excel(self, file_path, sheet_name):
        wb = openpyxl.load_workbook(file_path)
        sheet = wb[sheet_name]
        data = {}
        for col in range(1, sheet.max_column + 1):
            key = sheet.cell(row=1, column=col).value
            value = sheet.cell(row=2, column=col).value
            data[key] = value
        return data