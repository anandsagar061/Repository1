from time import sleep, time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from utils.Helper import Helper
from locators.intake_locators import IntakeLocators

class NewIntakePage(Helper):
    def __init__(self, driver):
        super().__init__(driver)

    def switch_to_nw_compass(self, expected_app):
        current_app = self.get_text(*IntakeLocators.APP_NAME_TEXT)
        if current_app != expected_app:
            self.click(*IntakeLocators.APP_LAUNCHER_BUTTON)
            sleep(2)
            self.click(*IntakeLocators.VIEW_ALL_BUTTON)
            sleep(2)
            locator = IntakeLocators.NW_COMPASS_APP_DIV(expected_app)
            element = self.driver.find_element(*locator)
            self.driver.execute_script("arguments[0].scrollIntoView({behavior:'smooth', block:'center'});", element)
            sleep(1)
            element.click()
            sleep(10)
    def verify_client_lookup_tab_visible(self,tab_name):
        return self.is_element_visible(*IntakeLocators.CLIENT_LOOKUP_TAB(tab_name))
    def click_client_lookup(self,tab_name):
        locator = IntakeLocators.CLIENT_LOOKUP_TAB(tab_name)
        self.safe_click(*locator)
        sleep(10)
    def verify_new_intake_button_visible(self,tab_name):
        return self.is_element_visible(*IntakeLocators.NEW_INTAKE_BUTTON(tab_name))
    def click_new_intake_button(self,tab_name):
        locator = IntakeLocators.NEW_INTAKE_BUTTON(tab_name)
        self.safe_click(*locator)
        sleep(5)

    def select_dropdown_by_label(self, label, value):
        # Click on dropdown based on label
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        wait = WebDriverWait(self.driver, 2)
        case_type = wait.until(EC.visibility_of_element_located((
            By.XPATH, f"//span[@title='{value}']"
        )))
        self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", case_type)
        case_type.click()
        sleep(5)

    def firstname_input(self, firstname):
        self.enter_text(*IntakeLocators.FIRST_NAME_INPUT, firstname)
        sleep(2)

    def lastname_input(self, lastname):
        self.enter_text(*IntakeLocators.LAST_NAME_INPUT, lastname)
        sleep(2)

    def email_address(self, email_address):
        self.enter_text(*IntakeLocators.EMAIL_INPUT,email_address)
        sleep(2)
    def dob(self,dob):
        self.enter_text(*IntakeLocators.BIRTHDATE_INPUT,dob)
        sleep(2)
    def mailing_street(self,mailing_street):
        self.enter_text(*IntakeLocators.MailingStreet,mailing_street)
        sleep(2)
    def mailing_city(self,mailing_city):
        self.enter_text(*IntakeLocators.MailingCity,mailing_city)
        sleep(2)
    def mailing_postcode(self,mailing_postcode):
        self.enter_text(*IntakeLocators.MailingPostCode,mailing_postcode)
        sleep(2)
    def select_english_proficiency(self,label,english_proficiency):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.english_option(english_proficiency)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def select_colonias_option(self,label,colonias_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.colonias_option(colonias_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def active_military_option(self,label,active_military_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.active_military_option(active_military_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def veteran_option(self,label,veteran_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.veteran_option(veteran_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def disabled_status_option(self,label,disabled_status_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.disabled_status_option(disabled_status_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def first_time_homebuyer_option(self,label,first_time_homebuyer_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.first_time_homebuyer_option(first_time_homebuyer_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def rural_area_status_option(self,label,rural_area_status_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.rural_area_status_option(rural_area_status_option)
        element = self.driver.find_element(*option_locator)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        element.click()
        sleep(2)
    def household_size_input(self,household_size_input):
        self.enter_text(*IntakeLocators.Household_Size_Input, household_size_input)
        sleep(2)
    def total_monthly_income_input(self,total_monthly_income_input):
        self.enter_text(*IntakeLocators.TotalMonthlyIncome_Input, total_monthly_income_input)
        sleep(2)
    def no_of_dependents_input(self, no_of_dependents_input):
        self.enter_text(*IntakeLocators.NumberOfDependents_Input, no_of_dependents_input)
        sleep(2)
    def occupation_input(self, occupation_input):
        self.enter_text(*IntakeLocators.Occupation_Input, occupation_input)
        sleep(2)
    def occupation_start_date_input(self, occupation_start_date_input):
        self.enter_text(*IntakeLocators.OccupationStartDate_Input, occupation_start_date_input)
        sleep(2)
    def monthly_creditors(self, monthly_creditors):
        self.enter_text(*IntakeLocators.MonthlyCreditorsDebt_Input, monthly_creditors)
        sleep(2)
    def client_hud_assistance_option(self,label,client_hud_assistance_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.client_hud_assistance_option(client_hud_assistance_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def current_residence_option(self,label,current_residence_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.current_residence_option(current_residence_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def household_type_option(self,label,household_type_option):
        dropdown_locator = IntakeLocators.DROPDOWN_BUTTON_BY_LABEL(label)
        self.click(*dropdown_locator)
        sleep(2)
        option_locator = IntakeLocators.household_type_option(household_type_option)
        element = self.driver.find_element(*option_locator)
        element.click()
        sleep(2)
    def occupation_start_date_option(self,label,occupation_start_date_option):
        self.enter_text(*IntakeLocators.occupation_start_date_option, occupation_start_date_option)
        sleep(2)
    def next_button(self):
        self.click(*IntakeLocators.Next_Button)
    def submit_button(self):
        self.click(*IntakeLocators.Submit_Button)