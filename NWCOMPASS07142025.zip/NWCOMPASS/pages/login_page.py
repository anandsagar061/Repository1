# pages/login_page.py
from time import sleep

from selenium.webdriver.common.by import By
from utils.Helper import Helper

class LoginPage(Helper):
    def login(self, username, password):
        self.enter_text(By.ID, "username", username)
        self.enter_text(By.ID, "password", password)
        self.click(By.ID, "Login")
        sleep(10)