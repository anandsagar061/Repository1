import pytest
import json
Shared_File = "shared_data.json"

def pytest_sessionstart(session):
    with open(Shared_File,"w") as json_file:
        json.dump([],json_file)