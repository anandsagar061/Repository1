import os
import random
import allure
from dotenv import load_dotenv
from pyexpat.errors import messages
from selenium import webdriver
import pytest
import json
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.edge.service import Service
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from dotenv import load_dotenv
import os
from conftest import Shared_File

# chrome_options = Options()

options = Options()
# options.add_argument("user-data-dir=C:\\Users\\Pvarakantam\\AppData\\Local\\Google\\Chrome\\User Data")
# options.add_argument("user-data-dir=C:\\Users\\Pvarakantam\\AppData\\Local\\Google\\Chrome\\User Data")
# Optional: Choose specific profile (e.g., "Profile 2")
# options.add_argument("profile-directory=Default")
Shared_File = "shared_data.json"

load_dotenv(dotenv_path="inputdata.env")



def get_user_data():
    with open("logindata.json") as logindata:
        users =  json.load(logindata)
        agency =[a.strip().lower() for a in os.getenv("AGENCY","").split(",")]
        persona =[a.strip().lower() for a in os.getenv("PERSONA","").split(",")]
        matched_user = [user for user in users
                        if user["Agency"].strip().lower() in agency and user["persona"].strip().lower() in persona]
    if not matched_user:
        raise Exception(f"No matching user found for  agency '{agency}'and persona'{persona}'")
    return matched_user

# def get_user_by_agency_persona(agency: str, persona: str):
#     users = load_users()
#     filtered_users = [user for user in users if user["Agency"] == agency and user["persona"] == persona]
#     if not filtered_users:
#         raise ValueError(f"No users found for agency: {agency} and persona: {persona}")
#     return filtered_users[0]


def load_created_users():
    if os.path.exists(Shared_File):
        with open(Shared_File) as json_file:
            return json.load(json_file)
    return []


@pytest.mark.parametrize("users", get_user_data())
def test_valid_login(users):
    print(users)
    driver = webdriver.Edge(options=options)
    driver.get("https://nwcompass--explorer.sandbox.my.salesforce.com/")
    driver.maximize_window()
    driver.find_element(By.ID, "username").send_keys(users["username"])
    driver.find_element(By.ID, "password").send_keys(users["password"])
    driver.find_element(By.ID, "Login").click()
    # driver.find_element(By.XPATH, "//button[@title='App Launcher']")
    time.sleep(10)
    appType = driver.find_element(By.XPATH, "//h1[contains(@class,'appName')]/span")
    if (appType.text != "NW Compass"):
        driver.find_element(By.XPATH, "//button[@title='App Launcher']").click()
        time.sleep(5)
        driver.find_element(By.XPATH, "//button[text()='View All']").click()
        time.sleep(5)
        element = driver.find_element(By.XPATH, "//div[@data-name='NW Compass']")
        driver.execute_script("arguments[0].scrollIntoView({behaviour:'smooth',block:'center'});", element)
        time.sleep(2)
        element.click()
    time.sleep(15)
    element = driver.find_element(By.XPATH, '//a[@title="Client Lookup"]')
    driver.execute_script("arguments[0].click();", element)
    time.sleep(5)
    # driver.find_element(By.XPATH, '//button[normalize-space()="New Intake"]').click()
    # driver.find_element(By.XPATH, '//button[text()="New Intake"]').click()
    driver.find_element(By.XPATH, "//button[normalize-space()='New Intake']").click()
    time.sleep(5)
    # driver.find_element(By.ID, "combobox-button-163").click()
    wait = WebDriverWait(driver, 20)
    combo_button = wait.until(EC.element_to_be_clickable((By.XPATH, '//button[@aria-label="Case Type"]')))
    combo_button.click()
    time.sleep(5)
    case_type = wait.until(EC.visibility_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Pre-purchase/Homebuying Counseling"]'
    )))
    case_type.click()
    # time.sleep(5)

    wait = WebDriverWait(driver, 20)
    combo_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@name='ReferralSource__c']")))
    combo_button.click()
    time.sleep(5)
    Hud_source = wait.until(EC.visibility_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Lender"]'
    )))
    Hud_source.click()

    firstname = users["firstname"] + str(random.randint(1, 1000))
    lastname = users["lastname"] + str(random.randint(1, 1000))
    email = f"{firstname.lower()}.{lastname.lower()}@yopmail.com"

    driver.find_element(By.XPATH, '(//input[@name="FirstName"])[2]').send_keys(firstname)
    driver.find_element(By.XPATH, '(//input[@name="LastName"])[2]').send_keys(lastname)
    driver.find_element(By.XPATH, '//*[text()="SSN"]//following::input[@name="Email"]').send_keys(email)

    driver.find_element(By.XPATH, '//input[@name="Birthdate"]').send_keys(users["Birthdate"])

    driver.find_element(By.XPATH, '//*[@name="MailingStreet"]').send_keys("123 Main St")

    driver.find_element(By.XPATH, '//*[@name="MailingCity"]').send_keys("Herndon")

    # State Selection
    wait = WebDriverWait(driver, 20)
    state_dropdown = wait.until(EC.element_to_be_clickable(
        (By.XPATH, '//button[@aria-label="State / Province"]')
    ))
    state_dropdown.click()
    state_selection = wait.until(EC.presence_of_element_located(
        (By.XPATH, '//lightning-base-combobox-item//span[text()="Virginia"]')
    ))
    driver.execute_script("arguments[0].scrollIntoView(true);", state_selection)
    state_selection.click()
    driver.find_element(By.XPATH, '//*[@name="MailingPostalCode"]').send_keys("20171")

    # County Selection
    # wait = WebDriverWait(driver, 30)
    # dropdown = wait.until(EC.element_to_be_clickable((By.XPATH, '//button[@aria-label="County"]')))
    # dropdown.click()
    # option = wait.until(EC.presence_of_element_located((
    #     By.XPATH, '//lightning-base-combobox-item//span[text()="Fairfax County"]'
    # )))
    # driver.execute_script("arguments[0].scrollIntoView(true);", option)
    # option.click()

    # Race Selection
    wait = WebDriverWait(driver, 20)
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Race"]')))
    driver.execute_script("arguments[0].click();", dropdown)
    option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Asian"]'
    )))
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Ethnicity Selection
    wait = WebDriverWait(driver, 20)
    ethnicity_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Ethnicity"]')))
    driver.execute_script("arguments[0].click();", ethnicity_dropdown)
    ethnicity_option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Hispanic"]'
    )))
    driver.execute_script("arguments[0].scrollIntoView(true);", ethnicity_option)
    driver.execute_script("arguments[0].click();", ethnicity_option)

    # Gender Selection

    wait = WebDriverWait(driver, 20)
    gender_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Gender"]')))
    driver.execute_script("arguments[0].click();", gender_dropdown)
    gender_option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Male"]'
    )))
    driver.execute_script("arguments[0].scrollIntoView(true);", gender_option)
    driver.execute_script("arguments[0].click();", gender_option)

    # Famr Worker Selection
    wait = WebDriverWait(driver, 20)
    farmworker_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Farm Worker"]')))
    driver.execute_script("arguments[0].click();", farmworker_dropdown)
    farmworker_option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Yes"]'
    )))
    driver.execute_script("arguments[0].scrollIntoView(true);", farmworker_option)
    driver.execute_script("arguments[0].click();", farmworker_option)

    # Education

    wait = WebDriverWait(driver, 20)

    # 1. Click the "Education" dropdown using JavaScript
    education_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Education"]')))
    driver.execute_script("arguments[0].click();", education_dropdown)

    # 2. Wait for the option to appear — replace the text with your target value
    education_option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="High School/GED"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", education_option)
    driver.execute_script("arguments[0].click();", education_option)

    # Marital Status

    wait = WebDriverWait(driver, 20)

    # 1. Locate and click the "Marital Status" dropdown using JavaScript
    marital_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Marital Status"]')))
    driver.execute_script("arguments[0].click();", marital_dropdown)

    # 2. Wait for the option to appear — replace with the actual label you want to select
    marital_option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//lightning-base-combobox-item//span[text()="Single"]'
    )))

    # 3. Scroll into view and click using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", marital_option)
    driver.execute_script("arguments[0].click();", marital_option)

    # English Proficiency

    wait = WebDriverWait(driver, 20)

    # 1. Locate and click the "English Proficiency" dropdown using JavaScript
    english_dropdown = wait.until(
        EC.presence_of_element_located((By.XPATH, '//button[@aria-label="English Proficiency"]')))
    driver.execute_script("arguments[0].click();", english_dropdown)

    # 2. Wait for the desired option to appear — replace the text with the actual value
    english_option = wait.until(EC.presence_of_element_located((
        By.XPATH, '//*[text()="English Proficiency"]//following::*[text()="Chose not to respond"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", english_option)
    driver.execute_script("arguments[0].click();", english_option)

    # Calonias Selection

    wait = WebDriverWait(driver, 20)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Colonias Resident"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Colonias Resident"]//following::*[text()="Yes"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Active Military"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Active Military"]//following::*[text()="Yes"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Veteran"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Veteran"]//following::*[text()="Yes"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Disabled Status"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Disabled Status"]//following::*[text()="Yes"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="1st Time Home Buyer"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="1st Time Home Buyer"]//following::*[text()="Yes"]'
    )))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Rural Area Status"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Rural Area Status"]//following::*[text()="Lives in a rural area"]')))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    driver.find_element(By.XPATH, '//*[text()="Household Size"]//following::input[1]').send_keys("10")

    # Financial

    driver.find_element(By.XPATH, '//*[text()="Total Monthly Income"]//following::input[1]').send_keys("100000")

    driver.find_element(By.XPATH, '//*[text()="Number of Dependents"]//following::input[1]').send_keys("20")

    driver.find_element(By.XPATH, '//*[text()="Occupation"]//following::input[1]').send_keys("Salaried")

    driver.find_element(By.XPATH, '//*[contains(text(),"Monthly Creditor")]//following::input[1]').send_keys("30000")

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Client HUD Assistance"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Client HUD Assistance"]//following::*[text()="Rental Voucher"]')))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Current Residence"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Current Residence"]//following::*[text()="Own"]')))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    # Step 1: Click the dropdown
    dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@aria-label="Household Type"]')))
    driver.execute_script("arguments[0].click();", dropdown)

    # Step 2: Wait for the full combobox item (not just the span)
    option = wait.until(EC.element_to_be_clickable((
        By.XPATH, '//*[text()="Household Type"]//following::*[text()="Single adult"]')))

    # 3. Scroll into view and click the option using JavaScript
    driver.execute_script("arguments[0].scrollIntoView(true);", option)
    driver.execute_script("arguments[0].click();", option)

    driver.find_element(By.XPATH, '//*[text()="Occupation Start Date"]//following::input[1]').send_keys("10/10/2024")

    time.sleep(20)
    # Click on Next button
    driver.find_element(By.XPATH, '//button[text()="Next"]').click()

    time.sleep(20)
    # driver.close()

    # Click on Next button
    driver.find_element(By.XPATH, '//button[text()="Next"]').click()

    time.sleep(15)

    # Click on Submit button
    driver.find_element(By.XPATH, '//button[text()="Submit"]').click()

    time.sleep(5)
    data = load_created_users()
    data.append(
        {"firstname": firstname, "lastname": lastname, "username": users["username"], "Agency": users["Agency"]})
    with open(Shared_File, 'w') as json_file:
        json.dump(data, json_file, indent=2)
    driver.quit()


@pytest.mark.parametrize("user", get_user_data())
def test_search_as_different_agency_user(user):
    created_user = load_created_users()
    driver = webdriver.Edge(options=options)
    wait = WebDriverWait(driver, 10)
    driver.get("https://nwcompass--explorer.sandbox.my.salesforce.com/")
    driver.maximize_window()
    driver.find_element(By.ID, "username").send_keys(user["username"])
    driver.find_element(By.ID, "password").send_keys(user["password"])
    driver.find_element(By.ID, "Login").click()
    time.sleep(10)
    appType = driver.find_element(By.XPATH, "//h1[contains(@class,'appName')]/span")
    if (appType.text != "NW Compass"):
        driver.find_element(By.XPATH, "//button[@title='App Launcher']").click()
        time.sleep(5)
        driver.find_element(By.XPATH, "//button[text()='View All']").click()
        time.sleep(5)
        element = driver.find_element(By.XPATH, "//div[@data-name='NW Compass']")
        driver.execute_script("arguments[0].scrollIntoView({behaviour:'smooth',block:'center'});", element)
        time.sleep(2)
        element.click()
    time.sleep(10)
    element = driver.find_element(By.XPATH, '//a[@title="Client Lookup"]')
    driver.execute_script("arguments[0].click();", element)
    time.sleep(10)
    for created_user in created_user:
        time.sleep(2)
        driver.find_element(By.XPATH, "//input[@name='FirstName']").clear()
        time.sleep(1)
        driver.find_element(By.XPATH, "//input[@name='FirstName']").send_keys(created_user["firstname"])
        time.sleep(1)
        driver.find_element(By.XPATH, "//input[@name='LastName']").clear()
        time.sleep(1)
        driver.find_element(By.XPATH, "//input[@name='LastName']").send_keys(created_user["lastname"])
        time.sleep(5)
        print(created_user["firstname"], created_user["lastname"])
        if created_user["Agency"] == user["Agency"]:
            try:
                show_history = driver.find_element(By.XPATH, "//span[@title='Show History']")
                assert show_history.is_displayed()
                print("Show History is visible")
            except AssertionError:
                print("Show History is not visible for same agency")
        elif created_user["Agency"] != user["Agency"]:
            try:
                message = driver.find_element(By.XPATH,
                                              "//div[text()='Please click Show History button next to Client Name to show client history.']")
                assert message.is_displayed()
                print("only message is displayed for different agency")
            except AssertionError:
                print("Show History is visible for different agency")
    driver.quit()




